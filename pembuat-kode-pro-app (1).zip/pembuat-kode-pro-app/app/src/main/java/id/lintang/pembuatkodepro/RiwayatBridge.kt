package id.lintang.pembuatkodepro

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Menyimpan riwayat kode Pro sebagai file di folder khusus aplikasi:
 *   <penyimpanan aplikasi>/files/riwayat_kode/<ID>.json
 * Satu file per ID perangkat (membuat kode untuk ID yang sama menimpa file lamanya).
 *
 * Cadangan: ekspor ke folder Download (satu file JSON) dan pulihkan dari file itu.
 */
class RiwayatBridge(
    private val activity: Activity,
    private val notify: (String) -> Unit
) {

    private val dir = File(activity.filesDir, "riwayat_kode").apply { mkdirs() }
    private var lastTs = 0L

    @Volatile
    private var pendingData: String? = null

    private val idRegex = Regex("^[A-Z0-9]{4}-[A-Z0-9]{4}$")
    private val codeRegex = Regex("^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$")

    @JavascriptInterface
    @Synchronized
    fun simpan(id: String, code: String, waktu: String): Boolean {
        if (!idRegex.matches(id) || !codeRegex.matches(code)) return false
        val ts = maxOf(System.currentTimeMillis(), lastTs + 1)
        lastTs = ts
        val json = JSONObject()
            .put("id", id)
            .put("code", code)
            .put("t", waktu.take(40))
            .put("ts", ts)
        return try {
            val tmp = File(dir, "$id.tmp")
            tmp.writeText(json.toString())
            Files.move(tmp.toPath(), File(dir, "$id.json").toPath(), StandardCopyOption.REPLACE_EXISTING)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** JSON array, terbaru di atas. */
    @JavascriptInterface
    @Synchronized
    fun muat(): String {
        val items = dir.listFiles { f -> f.extension == "json" }.orEmpty()
            .mapNotNull { f ->
                try { JSONObject(f.readText()) } catch (e: Exception) { null }
            }
            .sortedByDescending { it.optLong("ts") }
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        return arr.toString()
    }

    @JavascriptInterface
    @Synchronized
    fun hapusSemua() {
        dir.listFiles().orEmpty().forEach { it.delete() }
    }

    /** Cadangkan semua riwayat ke satu file JSON di folder Download. */
    @JavascriptInterface
    fun ekspor() {
        val data = muat()
        if (JSONArray(data).length() == 0) {
            notify("Belum ada riwayat untuk dicadangkan.")
            return
        }
        val nama = "cadangan-kode-pro-" +
            SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, nama)
                    put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    // Subfolder dibuat otomatis kalau belum ada.
                    put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER_CADANGAN
                    )
                }
                val uri = activity.contentResolver
                    .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IOException("tidak bisa membuat file")
                activity.contentResolver.openOutputStream(uri)!!.use {
                    it.write(data.toByteArray(Charsets.UTF_8))
                }
                notify("Tersimpan di Download/$FOLDER_CADANGAN: $nama")
            } catch (e: Exception) {
                notify("Gagal mencadangkan: ${e.message}")
            }
        } else {
            // Android 8 sampai 9: lewat pemilih lokasi sistem (tanpa izin tambahan).
            pendingData = data
            activity.runOnUiThread {
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, nama)
                }
                @Suppress("DEPRECATION")
                activity.startActivityForResult(i, REQ_EKSPOR)
            }
        }
    }

    /** Pulihkan riwayat dari file cadangan (digabung dengan riwayat yang ada). */
    @JavascriptInterface
    fun impor() {
        activity.runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            @Suppress("DEPRECATION")
            activity.startActivityForResult(i, REQ_IMPOR)
        }
    }

    /** Dipanggil dari Activity.onActivityResult. True jika hasilnya milik kelas ini. */
    fun handleResult(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQ_EKSPOR && requestCode != REQ_IMPOR) return false
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            pendingData = null
            return true
        }
        try {
            if (requestCode == REQ_EKSPOR) {
                val isi = pendingData ?: return true
                activity.contentResolver.openOutputStream(uri)!!.use {
                    it.write(isi.toByteArray(Charsets.UTF_8))
                }
                pendingData = null
                notify("Cadangan tersimpan.")
            } else {
                val bytes = activity.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size > 1_000_000) throw IOException("file terlalu besar")
                val arr = JSONArray(String(bytes, Charsets.UTF_8))
                var ok = 0
                // File cadangan urut terbaru dulu; simpan dari yang terlama agar urutan terjaga.
                for (n in arr.length() - 1 downTo 0) {
                    val o = arr.optJSONObject(n) ?: continue
                    if (simpan(o.optString("id"), o.optString("code"), o.optString("t"))) ok++
                }
                notify("$ok kode dipulihkan.")
            }
        } catch (e: Exception) {
            notify("Gagal: ${e.message}")
        }
        return true
    }

    companion object {
        const val FOLDER_CADANGAN = "Pembuat Kode Pro"
        const val REQ_EKSPOR = 4101
        const val REQ_IMPOR = 4102
    }
}
