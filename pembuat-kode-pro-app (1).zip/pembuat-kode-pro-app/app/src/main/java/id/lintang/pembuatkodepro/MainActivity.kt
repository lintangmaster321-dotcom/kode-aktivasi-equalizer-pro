package id.lintang.pembuatkodepro

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONObject

/**
 * Membungkus pembuat-kode-pro.html (di assets) dalam WebView.
 * Semua berjalan offline; riwayat kode tersimpan di localStorage WebView milik aplikasi ini.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var riwayat: RiwayatBridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bg = Color.parseColor("#121418")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        webView = WebView(this).apply {
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true            // localStorage untuk riwayat kode
                allowContentAccess = false
                allowFileAccess = false             // file:///android_asset tetap bisa dibaca
                cacheMode = WebSettings.LOAD_NO_CACHE
                setSupportZoom(false)
            }
            webViewClient = object : WebViewClient() {
                // Tolak semua navigasi keluar dari halaman lokal.
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean = request.url.toString() != ASSET_URL
            }
        }

        riwayat = RiwayatBridge(this, ::kirimPesan)
        webView.addJavascriptInterface(riwayat, "RiwayatApp")

        // Android 15 (targetSdk 35) menggambar sampai ke bawah bilah sistem,
        // jadi beri ruang di sekitar konten.
        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            addView(webView)
            @Suppress("DEPRECATION")
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    maxOf(insets.systemWindowInsetBottom, insets.stableInsetBottom)
                )
                insets
            }
        }
        setContentView(root)

        if (savedInstanceState == null) {
            webView.loadUrl(ASSET_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        if (!riwayat.handleResult(requestCode, resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    /** Kirim pesan status ke halaman (aman dipanggil dari thread mana pun). */
    private fun kirimPesan(pesan: String) {
        runOnUiThread {
            webView.evaluateJavascript(
                "window.onRiwayat && window.onRiwayat(" + JSONObject.quote(pesan) + ")", null
            )
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private val ASSET_URL: String = "file:///android_asset/pembuat-kode-pro.html"
    }
}
