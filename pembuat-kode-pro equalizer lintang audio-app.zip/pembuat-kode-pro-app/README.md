# Pembuat Kode Pro (aplikasi Android)

Membungkus `app/src/main/assets/pembuat-kode-pro.html` dalam aplikasi Android. Berjalan offline, tanpa izin internet.

## Cara membuat APK

**A. Android Studio**
1. File > Open, pilih folder ini, tunggu sinkronisasi Gradle.
2. Build > Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.
3. Kirim APK ke HP, buka, izinkan "install dari sumber tidak dikenal".

**B. GitHub Actions (tanpa Android Studio)**
1. Buat repositori **privat** di GitHub, unggah isi folder ini (termasuk `.github`).
2. Buka tab Actions > Build APK > Run workflow.
3. Unduh `PembuatKodePro-apk` dari bagian Artifacts, ekstrak, pasang `app-debug.apk`.

## Mengubah isi
Edit `app/src/main/assets/pembuat-kode-pro.html`, lalu build ulang. Kalau `SECRET` diganti, ganti juga di `Pro.kt` dan `tools/buat_kode_pro.py`.

## Catatan keamanan
APK ini memuat `SECRET`. Jangan bagikan APK maupun repositorinya (pakai repositori privat).
