package id.lintang.pembuatkodepro

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Membungkus pembuat-kode-pro.html (di assets) dalam WebView.
 * Semua berjalan offline; riwayat kode tersimpan di localStorage WebView milik aplikasi ini.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bg = Color.parseColor("#121418")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        webView = WebView(this).apply {
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true            // localStorage untuk riwayat kode
                allowContentAccess = false
                allowFileAccess = false             // file:///android_asset tetap bisa dibaca
                cacheMode = WebSettings.LOAD_NO_CACHE
                setSupportZoom(false)
            }
            webViewClient = object : WebViewClient() {
                // Tolak semua navigasi keluar dari halaman lokal.
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean = request.url.toString() != ASSET_URL
            }
        }

        // Android 15 (targetSdk 35) menggambar sampai ke bawah bilah sistem,
        // jadi beri ruang di sekitar konten.
        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            addView(webView)
            @Suppress("DEPRECATION")
            setOnApplyWindowInsetsListener { v, insets ->
                v.setPadding(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    maxOf(insets.systemWindowInsetBottom, insets.stableInsetBottom)
                )
                insets
            }
        }
        setContentView(root)

        if (savedInstanceState == null) {
            webView.loadUrl(ASSET_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val ASSET_URL = "file:///android_asset/pembuat-kode-pro.html"
    }
}
